import React from 'react';
import { Users } from 'lucide-react';

export default function CustomersPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 tracking-tight flex items-center gap-2.5">
            <Users className="w-6 h-6 text-indigo-600" />
            <span>Customers CRM</span>
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            Manage customer accounts, business details, GST records, and follow-up timeline notes.
          </p>
        </div>
      </div>

      <div className="bg-white border border-gray-200 rounded-lg p-12 text-center">
        <div className="w-12 h-12 rounded-full bg-indigo-50 flex items-center justify-center text-indigo-600 mx-auto mb-3">
          <Users className="w-6 h-6" />
        </div>
        <h3 className="text-base font-semibold text-gray-900">Customers CRM Module Ready</h3>
        <p className="text-sm text-gray-500 max-w-md mx-auto mt-1">
          Auth & route protection are working. Next step will render the paginated customer table, search, filters, and note drawer.
        </p>
      </div>
    </div>
  );
}
