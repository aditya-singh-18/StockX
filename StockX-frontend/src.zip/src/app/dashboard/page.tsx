import React from 'react';
import { cookies } from 'next/headers';
import {
  Users,
  Package,
  ScrollText,
  ShieldCheck,
  Activity,
  CheckCircle2,
  Lock,
  ArrowUpRight,
} from 'lucide-react';
import { API_BASE_URL } from '@/lib/api';

export default async function DashboardPage() {
  const cookieStore = await cookies();
  const userCookie = cookieStore.get('stockflow_user')?.value;
  const accessToken = cookieStore.get('stockflow_access_token')?.value;

  let user = null;
  if (userCookie) {
    try {
      user = JSON.parse(userCookie);
    } catch {
      user = null;
    }
  }

  // Fetch live stats from live Render backend
  let customersCount = 0;
  let productsCount = 0;
  let challansCount = 0;
  let backendOnline = false;

  if (accessToken) {
    try {
      const [custRes, prodRes, chalRes] = await Promise.allSettled([
        fetch(`${API_BASE_URL}/customers?limit=1`, {
          headers: { Authorization: `Bearer ${accessToken}` },
        }).then((r) => (r.ok ? r.json() : null)),
        fetch(`${API_BASE_URL}/products?limit=1`, {
          headers: { Authorization: `Bearer ${accessToken}` },
        }).then((r) => (r.ok ? r.json() : null)),
        fetch(`${API_BASE_URL}/challans?limit=1`, {
          headers: { Authorization: `Bearer ${accessToken}` },
        }).then((r) => (r.ok ? r.json() : null)),
      ]);

      if (custRes.status === 'fulfilled' && custRes.value) {
        customersCount = custRes.value.total || 0;
        backendOnline = true;
      }
      if (prodRes.status === 'fulfilled' && prodRes.value) {
        productsCount = prodRes.value.total || 0;
        backendOnline = true;
      }
      if (chalRes.status === 'fulfilled' && chalRes.value) {
        challansCount = chalRes.value.total || 0;
        backendOnline = true;
      }
    } catch {
      backendOnline = false;
    }
  }

  const roleBadgeStyle =
    user?.role === 'Admin'
      ? 'bg-purple-50 text-purple-700 border-purple-200'
      : user?.role === 'Sales'
      ? 'bg-blue-50 text-blue-700 border-blue-200'
      : user?.role === 'Warehouse'
      ? 'bg-amber-50 text-amber-700 border-amber-200'
      : 'bg-emerald-50 text-emerald-700 border-emerald-200';

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold text-gray-900 tracking-tight">
              Welcome, {user?.name || 'User'}
            </h1>
            <span
              className={`text-xs font-semibold px-2.5 py-1 rounded-md border ${roleBadgeStyle}`}
            >
              {user?.role || 'Guest'} Role
            </span>
          </div>
          <p className="text-sm text-gray-500 mt-1">
            Logged in as <span className="font-mono text-gray-700">{user?.email}</span>
          </p>
        </div>

        {/* Live Backend Indicator */}
        <div className="flex items-center gap-2 px-3 py-1.5 bg-white border border-gray-200 rounded-lg text-xs font-medium text-gray-700 shadow-2xs">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span>Live API:</span>
          <span className="font-mono text-gray-900">stockx-7dz7.onrender.com</span>
        </div>
      </div>

      {/* Operational Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Customers CRM Card */}
        <div className="bg-white border border-gray-200 rounded-lg p-5 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
              Total Customers
            </span>
            <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center text-blue-600">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-3xl font-bold text-gray-900">{customersCount}</div>
            <p className="text-xs text-gray-500 mt-1 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
              <span>CRM & Follow-up Timeline</span>
            </p>
          </div>
        </div>

        {/* Inventory Products Card */}
        <div className="bg-white border border-gray-200 rounded-lg p-5 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
              Catalog Products
            </span>
            <div className="w-8 h-8 rounded-lg bg-indigo-50 flex items-center justify-center text-indigo-600">
              <Package className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-3xl font-bold text-gray-900">{productsCount}</div>
            <p className="text-xs text-gray-500 mt-1 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
              <span>Inventory & Low-Stock Alerts</span>
            </p>
          </div>
        </div>

        {/* Sales Challans Card */}
        <div className="bg-white border border-gray-200 rounded-lg p-5 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
              Sales Challans
            </span>
            <div className="w-8 h-8 rounded-lg bg-purple-50 flex items-center justify-center text-purple-600">
              <ScrollText className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-3xl font-bold text-gray-900">{challansCount}</div>
            <p className="text-xs text-gray-500 mt-1 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
              <span>Atomic Stock Confirmation</span>
            </p>
          </div>
        </div>
      </div>

      {/* Dynamic Role Capabilities Matrix */}
      <div className="bg-white border border-gray-200 rounded-lg p-6 shadow-2xs">
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-gray-100">
          <div>
            <h2 className="text-base font-semibold text-gray-900 flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-indigo-600" />
              <span>Granted Permissions & Dynamic Capabilities</span>
            </h2>
            <p className="text-xs text-gray-500 mt-0.5">
              Zero hardcoding: UI actions and sidebar views are dynamically driven by this array.
            </p>
          </div>
          <span className="text-xs font-mono px-2.5 py-1 rounded bg-gray-100 text-gray-700 font-semibold">
            {user?.permissions?.length || 0} Active Permissions
          </span>
        </div>

        <div className="flex flex-wrap gap-2">
          {user?.permissions?.map((perm: string) => (
            <span
              key={perm}
              className="inline-flex items-center gap-1.5 px-3 py-1 bg-gray-50 border border-gray-200 rounded-md text-xs font-mono text-gray-800"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-500"></span>
              {perm}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
