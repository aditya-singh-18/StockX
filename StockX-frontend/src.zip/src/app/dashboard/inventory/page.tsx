import React from 'react';
import { Package } from 'lucide-react';

export default function InventoryPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 tracking-tight flex items-center gap-2.5">
            <Package className="w-6 h-6 text-indigo-600" />
            <span>Products & Inventory</span>
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            Product catalog, real-time stock levels, low-stock threshold alerts, and atomic audit trails.
          </p>
        </div>
      </div>

      <div className="bg-white border border-gray-200 rounded-lg p-12 text-center">
        <div className="w-12 h-12 rounded-full bg-indigo-50 flex items-center justify-center text-indigo-600 mx-auto mb-3">
          <Package className="w-6 h-6" />
        </div>
        <h3 className="text-base font-semibold text-gray-900">Inventory Module Ready</h3>
        <p className="text-sm text-gray-500 max-w-md mx-auto mt-1">
          Auth & route protection verified. Next step will render product table, low-stock badge, and inward/outward adjustment modal.
        </p>
      </div>
    </div>
  );
}
